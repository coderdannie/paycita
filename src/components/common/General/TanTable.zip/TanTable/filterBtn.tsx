import { Button } from "@material-tailwind/react";
import { SlidersHorizontal } from "@phosphor-icons/react";
import React from "react";

const FilterBtn = ({ func }: { func: () => void }) => {
	return (
		<Button
			className='flex items-center gap-2 px-4 border-pry text-pry border-[1px] bg-transparent normal-case font-medium'
			onClick={func}
		>
			Filter
			<SlidersHorizontal size={20} />
		</Button>
	);
};

export default FilterBtn;
