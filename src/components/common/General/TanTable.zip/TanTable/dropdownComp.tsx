import React from "react";

interface DropdownCompProps {
  options: string[];
  selectedValue: string;
  setSelectedValue: (value: string) => void;
  placeholder: string;
}

const DropdownComp: React.FC<DropdownCompProps> = ({
  options,
  selectedValue,
  setSelectedValue,
  placeholder,
}) => {
  return (
    <select
      value={selectedValue}
      onChange={(e:any) => setSelectedValue(e.target.value)}
      className="p-2 border border-gray-300 rounded-md"
    >
      <option value="">{placeholder}</option>
      {options.map((option:any, index:any) => (
        <option key={index} value={option}>
          {option}
        </option>
      ))}
    </select>
  );
};

export default DropdownComp;
